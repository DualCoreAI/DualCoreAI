# notificari.py
import os
import json
from datetime import datetime, timedelta
import pytz
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail
from apscheduler.schedulers.background import BackgroundScheduler
from dotenv import load_dotenv
import ssl
import certifi


ssl._create_default_https_context = ssl.create_default_context
ssl_context = ssl.create_default_context(cafile=certifi.where())

# Încarcă variabilele din .env
load_dotenv()

# Setează fusul orar pentru România
eest = pytz.timezone("Europe/Bucharest")

# Variabile pentru email
FROM_EMAIL = os.getenv("SENDGRID_FROM_EMAIL", "andrei.puchiu999@gmail.com")
API_KEY = os.getenv("SENDGRID_API_KEY")

# Verifică dacă cheia API e disponibilă
if not API_KEY:
    print("❌ Lipsă SENDGRID_API_KEY în .env")
else:
    print("✅ SendGrid API Key încărcată")

# Inițializează planificatorul
scheduler = BackgroundScheduler()

def trimite_email(to_email, subject, content):
    """Trimite un email prin SendGrid"""
    if not API_KEY:
        print("❌ Nu se poate trimite email: API Key lipsă")
        return
    try:
        os.environ["SSL_CERT_FILE"] = certifi.where()
        sg = SendGridAPIClient(api_key=API_KEY)
        message = Mail(
            from_email=FROM_EMAIL,
            to_emails=to_email,
            subject=subject,
            html_content=content
        )
        response = sg.send(message)
        print(f"✅ Email trimis la {to_email}")
    except Exception as e:
        print(f"❌ Eroare trimitere email: {e}")

def verifica_notificari():
    """Verifică dacă este momentul de a trimite notificări pentru sesiuni"""
    now = datetime.now(eest)
    print(f"🔍 Verificare notificări la: {now}")

    # Verifică dacă fișierele există
    if not os.path.exists("utilizatori.json") or not os.path.exists("sesiuni.json"):
        print("⚠ Fișiere lipsă: utilizatori.json sau sesiuni.json")
        return

    # Încarcă utilizatorii și sesiunile
    try:
        with open("utilizatori.json", "r", encoding="utf-8") as f:
            users = json.load(f)
        with open("sesiuni.json", "r", encoding="utf-8") as f:
            sesiuni = json.load(f)
    except Exception as e:
        print(f"❌ Eroare citire fișiere: {e}")
        return

    # Parcurge fiecare utilizator și sesiune
    for user in users:
        email = user["email"]
        for sesiune in sesiuni:
            if sesiune["nume"] in user.get("sesiuni", []):
                try:
                    # Parsează ora sesiunii și aplică fusul orar (EEST)
                    ora_sesiune_naive = datetime.fromisoformat(sesiune["ora"])
                    ora_sesiune = eest.localize(ora_sesiune_naive)
                    cu_15_min = ora_sesiune - timedelta(minutes=15)

                    # Verifică dacă e momentul de notificare (cu 15 min înainte)
                    if now >= cu_15_min and now < ora_sesiune:
                        if not user.get("notificat", {}).get(sesiune["nume"], False):
                            mesaj = f"""
                            <h2>🔔 {sesiune['nume']} începe în 15 minute!</h2>
                        
                            """
                            trimite_email(
                                email,
                                f"⏰ {sesiune['nume']} începe în 15 minute!",
                                mesaj
                            )
                            # Marchează ca notificat
                            if "notificat" not in user:
                                user["notificat"] = {}
                            user["notificat"][sesiune["nume"]] = True
                            # Salvează starea
                            with open("utilizatori.json", "w", encoding="utf-8") as f:
                                json.dump(users, f, indent=4, ensure_ascii=False)
                except Exception as e:
                    print(f"❌ Eroare procesare sesiune {sesiune['nume']}: {e}")

# Adaugă job-ul de verificare la fiecare minut
scheduler.add_job(verifica_notificari, 'interval', minutes=1)


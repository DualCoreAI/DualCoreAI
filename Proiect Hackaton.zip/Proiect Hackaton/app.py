from flask import Flask, request, jsonify, render_template
from openai import OpenAI
import os
from dotenv import load_dotenv
from db import salveaza_utilizator

load_dotenv()
app = Flask(__name__)

# ✅ Creează clientul corect
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))


@app.route("/")
def home():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    intrebare = request.json.get("message", "")

    # Încarcă programul hackathonului
    with open("sesiuni.json", "r", encoding="utf-8") as f:
        sesiuni_data = f.read()

    try:
        raspuns = client.chat.completions.create(
            model="gpt-4o-mini",  # ✅ folosește un model mai bun și rapid
            messages=[
                {
                    "role": "system",
                    "content": (
                        "Ești un asistent virtual pentru Craiova Hackathon 2025. "
                        "Răspunzi mereu în limba română, clar și prietenos. "
                        "Evenimentul are loc în Craiova între 20–22 octombrie, "
                        "la Muzeul de Artă Craiova – Brâncuși’s Prism. "
                        "Iată programul complet al evenimentului (cu ore și durate):\n\n"
                        f"{sesiuni_data}\n\n"
                        "Folosește aceste date pentru a răspunde la întrebările despre program, sesiuni, durate sau locație."
                    ),
                },
                {"role": "user", "content": intrebare},
            ],
        )

        mesaj_final = raspuns.choices[0].message.content.strip()
        return jsonify({"response": mesaj_final})

    except Exception as e:
        print("Eroare:", e)
        return jsonify({"response": "A apărut o eroare la generarea răspunsului. Încearcă din nou!"})



@app.route("/inscrie", methods=["POST"])
def inscrie():
    email = request.form["email"]
    sesiuni = request.form.getlist("sesiuni")
    salveaza_utilizator(email, sesiuni)
    return "Inscris cu succes!"
if __name__ == "__main__":
    from notificari import scheduler
    import os
    if os.environ.get("WERKZEUG_RUN_MAIN") == "true":
        scheduler.start()
    app.run(port=5001, debug=True)

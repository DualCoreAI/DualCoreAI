# db.py
import json
import os

DB_FILE = "utilizatori.json"

def incarca_utilizatori():
    """Încarcă lista de utilizatori din fișierul JSON"""
    if os.path.exists(DB_FILE):
        with open(DB_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return []  # dacă fișierul nu există, întoarce o listă goală

def salveaza_utilizator(email, sesiuni):
    """Salvează un nou utilizator în baza de date"""
    users = incarca_utilizatori()
    users.append({"email": email, "sesiuni": sesiuni})
    with open(DB_FILE, "w", encoding="utf-8") as f:
        json.dump(users, f, indent=4, ensure_ascii=False)
        